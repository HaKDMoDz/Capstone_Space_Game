﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AI_System_Workshop
{
    class AI_Objective
    {
        public AI_Objective()
        {
            Console.WriteLine("AI_Objective created");
        }
    }
}
