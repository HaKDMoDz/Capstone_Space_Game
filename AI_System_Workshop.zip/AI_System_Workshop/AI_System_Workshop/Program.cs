﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GeneticAlgorithm;

namespace AI_System_Workshop
{
    class Program
    {
        static void Main(string[] args)
        {
            //test genetic Algorithm
            //Population pop1 = new Population(10);
            //success 

            AISystem testAISystem = new AISystem();

            Console.ReadLine();
        }
    }
}
